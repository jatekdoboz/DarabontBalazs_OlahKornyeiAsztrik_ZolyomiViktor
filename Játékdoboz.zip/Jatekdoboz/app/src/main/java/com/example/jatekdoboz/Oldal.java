package com.example.jatekdoboz;

import android.graphics.Bitmap;

public class Oldal {
    private String oldalak;

    public Oldal(String oldalak) {
        this.oldalak = oldalak;
    }

    public String getOldalak() { return oldalak; }

}
