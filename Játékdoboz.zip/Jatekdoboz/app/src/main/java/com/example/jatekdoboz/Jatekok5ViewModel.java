package com.example.jatekdoboz;

import androidx.lifecycle.ViewModel;

public class Jatekok5ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}