package com.example.jatekhaboru6.ui.home;

import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import junit.framework.TestCase;

public class KepfeltoltesTest extends TestCase {

    public void testKepfajlNev(Uri uri) {
        String kepfajlnev;
        //Cursor returnCursor =
        //        getContext().getContentResolver().query(uri, null, null, null, null);
       // assert returnCursor != null;
        //int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
       // returnCursor.moveToFirst();
       // String name = returnCursor.getString(nameIndex);
       // returnCursor.close();
       // kepfajlnev=name;
    }

    public void testBillentyuzetelrejt() {
    }

    public void testKepFeltoltes() {
    }

    public void testKicsiKepFeltoltes() {
    }
}