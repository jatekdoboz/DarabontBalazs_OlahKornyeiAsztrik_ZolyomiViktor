package com.example.jatekhaboru6.Remote

interface IUploadAPI {
}