package com.example.jatekhaboru6;

import androidx.lifecycle.ViewModel;

public class Jatekok5ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}