package com.example.jatekhaboru6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class tesztactivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tesztactivity);
    }

    public void valami() {}
}