package com.example.jatekhaboru6;

public class Adatok {

    public static int pontok;
    public static int feltoltottjatekok;
}
