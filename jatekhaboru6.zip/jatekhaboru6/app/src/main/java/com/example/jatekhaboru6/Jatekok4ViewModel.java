package com.example.jatekhaboru6;

import androidx.lifecycle.ViewModel;

public class Jatekok4ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}